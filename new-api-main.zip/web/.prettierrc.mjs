module.exports = require('@so1ve/prettier-config');
